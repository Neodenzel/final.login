/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login2;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

class Task {
    // ... (Task class remains unchanged)
}

public class Login2 {
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private Task[] tasks;
    private int taskCount;

    private String[] developers;
    private String[] taskNames;
    private String[] taskIDs;
    private int[] taskDurations;
    private String[] taskStatuses;

    public Login2() {
        this.username = "";
        this.password = "";
        this.firstName = "";
        this.lastName = "";
        this.tasks = new Task[100]; // Assuming a maximum of 100 tasks
        this.taskCount = 0;

        this.developers = new String[100];
        this.taskNames = new String[100];
        this.taskIDs = new String[100];
        this.taskDurations = new int[100];
        this.taskStatuses = new String[100];
    }

    public void registerUser() {
        String username = JOptionPane.showInputDialog(null, "Enter your username that has 5 characters in it(we recommend you use a underscore in your username):");
        String password = JOptionPane.showInputDialog(null, "Enter your password that has 8 characters in it (we recommend complicating it by using special characters):");
        String firstName = JOptionPane.showInputDialog(null, "Enter your first name:");
        String lastName = JOptionPane.showInputDialog(null, "Enter your last name:");

        if (!checkUserName(username)) {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return;
        }
        if (!checkPasswordComplexity(password)) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return;
        }

        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;

        JOptionPane.showMessageDialog(null, "User registered successfully.");
    }

    public boolean loginUser() {
        String enteredUsername = JOptionPane.showInputDialog(null, "Enter your username:");
        String enteredPassword = JOptionPane.showInputDialog(null, "Enter your password:");

        if (enteredUsername.equals(username) && enteredPassword.equals(password)) {
            JOptionPane.showMessageDialog(null, "Welcome, " + firstName + " " + lastName + ". It's great to see you again.");
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect. Please try again.");
            return false;
        }
    }

    private boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    private boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*()-_=+\\|[{]};:'\",<.>/?].*");
    }

    private void addTasks() {
        // ... (addTasks method remains unchanged)
    }

    private void displayDoneTasks() {
        // ... (displayDoneTasks method remains unchanged)
    }

    private void displayLongestTask() {
        // ... (displayLongestTask method remains unchanged)
    }

    private void searchTaskByName() {
        // ... (searchTaskByName method remains unchanged)
    }

    private void searchTasksByDeveloper() {
        // ... (searchTasksByDeveloper method remains unchanged)
    }

    private void deleteTask() {
        // ... (deleteTask method remains unchanged)
    }

    private void displayTaskReport() {
        // ... (displayTaskReport method remains unchanged)
    }

    private void showMenu() {
        while (true) {
            String[] options = {"Add tasks", "Display tasks with 'Done' status", "Display task with longest duration",
                                "Search task by name", "Search tasks by developer", "Delete task", "Display task report", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    addTasks();
                    break;
                case 1:
                    displayDoneTasks();
                    break;
                case 2:
                    displayLongestTask();
                    break;
                case 3:
                    searchTaskByName();
                    break;
                case 4:
                    searchTasksByDeveloper();
                    break;
                case 5:
                    deleteTask();
                    break;
                case 6:
                    displayTaskReport();
                    break;
                case 7:
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice, please try again.");
                    break;
            }
        }
    }

    public static void main(String[] args) {
        Login2 login = new Login2();
        JFrame frame = new JFrame("Login System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setVisible(true);

        int option = JOptionPane.showConfirmDialog(frame, "Do you want to register a new user?", "Register User", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            login.registerUser();
        }

        while (!login.loginUser()) {
            // Keep prompting for login until successful
        }

        login.showMenu();
    }
}